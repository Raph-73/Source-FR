/* ============================================================================
 * Franime (franime.fr) — French anime module for Synthetiq Player (contract v4)
 * ----------------------------------------------------------------------------
 * Chain (observed live 2026-09-18, catalogue + resolver + embeds):
 *   catalogue : GET https://api.franime.fr/api/animes
 *                 -> JSON array of ~2500 anime objects, each with id (number),
 *                    title/titleO/titles{en,en_us,en_jp,ja_jp}, description,
 *                    affiche/affiche_small, note, themes[], format, status,
 *                    startDate, nsfw, saisons[] (each with episodes[] each with
 *                    lang.vo/vf.lecteurs[] provider-name arrays).
 *   details   : GET https://api.franime.fr/api/anime-by-id/:id -> same object.
 *   lecteur   : GET https://api.franime.fr/api/anime/:id/:saison/:ep/:lang/:idx
 *                 (0-based indices, lang vo|vf) -> plain-text watch2 URL.
 *                 REQUIRES browser-like headers (UA + Accept + Content-Type
 *                 application/json + Origin/Referer + Sec-Fetch-*); minimal
 *                 headers get Cloudflare HTTP 403 on this route only.
 *   watch2    : https://franime.fr/watch2/?a=...&b=... -> each param is
 *                 base64(hex-bytes XOR single-byte key); brute-force 0..255,
 *                 keep values starting with http(s):// on a known provider.
 *   providers : sibnet (shell.php -> /v/<token>/<id>.mp4 -> 302 CDN mp4),
 *                 vidmoly (embed html jwplayer file: ...m3u8),
 *                 sendvid (embed html <source src> or file: ...mp4/m3u8).
 *                 filemoon mirrors (e.g. bysedikamoum.com) need a browser PoW
 *                 and are SKIPPED. "TELECHARGEMENT ..." lecteurs are skipped.
 *   identity  : anime id is the numeric catalogue id (stringified).
 *                 episode href: "franime://<id>/<saisonIdx>/<episodeIdx>"
 *                 (0-based indices into saisons[]/episodes[]).
 *   audio     : vo = VOSTFR (original audio, French subs) -> lang "sub".
 *                 vf = Version Francaise (French dub)      -> lang "dub".
 *                 No soft-subtitle URLs are exposed by the source; VOSTFR
 *                 captions are part of the video itself. subtitles: [] always.
 *
 * No Node or DOM dependencies. Only fetchv2 + standard JS. No atob/btoa,
 * no typed arrays (own base64/hex codec on plain arrays/strings).
 * ==========================================================================*/
(function () {
  'use strict';

  var SITE = 'https://franime.fr';
  var API = 'https://api.franime.fr';
  var UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36';
  var API_HEADERS = {
    'User-Agent': UA,
    'Accept': 'application/json, text/plain, */*',
    'Content-Type': 'application/json',
    'Accept-Language': 'fr-FR,fr;q=0.9,en;q=0.8',
    'Origin': SITE,
    'Referer': SITE + '/',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'same-site'
  };
  var HTML_HEADERS = {
    'User-Agent': UA,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'fr-FR,fr;q=0.9,en;q=0.8',
    'Referer': SITE + '/'
  };
  var STREAM_HEADERS = { 'User-Agent': UA, 'Referer': SITE + '/', 'Origin': SITE };

  var PROVIDER_SUBSTRINGS = ['sibnet.ru', 'vidmoly', 'sendvid', 'filemoon', 'bysedikamoum', 'streamtape', 'doodstream', 'dood'];
  var UNSUPPORTED_LECTEURS = ['filemoon', 'telechargement'];

  var catalogueCache = { at: 0, items: null };

  function now() { return Date.now(); }
  function timeLeft(deadline, cap) {
    var left = deadline - now();
    if (left < 600) return 600;
    if (cap && left > cap) return cap;
    return left;
  }

  function clean(value) {
    return String(value == null ? '' : value)
      .replace(/<[^>]*>/g, ' ')
      .replace(/&nbsp;/gi, ' ')
      .replace(/&amp;/gi, '&').replace(/&quot;/gi, '"')
      .replace(/&#0?39;|&apos;|&#x27;/gi, "'")
      .replace(/&eacute;|&#xe9;/gi, 'e').replace(/&egrave;|&#xe8;/gi, 'e')
      .replace(/&ecirc;|&#xea;/gi, 'e').replace(/&agrave;|&#xe0;/gi, 'a')
      .replace(/&ccedil;|&#xe7;/gi, 'c').replace(/&ocirc;|&#xf4;/gi, 'o')
      .replace(/&icirc;|&#xee;/gi, 'i').replace(/&ucirc;|&#xfb;/gi, 'u')
      .replace(/\s+/g, ' ').trim();
  }

  function mergeHeaders(extra) {
    var out = {}, k;
    for (k in API_HEADERS) out[k] = API_HEADERS[k];
    if (extra) for (k in extra) out[k] = extra[k];
    return out;
  }
  function mergeHtmlHeaders(extra) {
    var out = {}, k;
    for (k in HTML_HEADERS) out[k] = HTML_HEADERS[k];
    if (extra) for (k in extra) out[k] = extra[k];
    return out;
  }

  /* ---------------- transport helpers (fetchv2 with JSON-shape tolerance) -- */
  async function requestText(url, headers, timeoutMs, options) {
    var opts = { timeoutMs: timeoutMs };
    if (options) for (var k in options) opts[k] = options[k];
    var res = await fetchv2(url, headers || {}, 'GET', null, opts);
    var status = Number(res && (res.status || res.statusCode)) || 0;
    var text = '';
    if (res && typeof res.text === 'function') {
      try { text = await res.text(); } catch (_) { text = ''; }
    } else if (res && typeof res.body === 'string') {
      text = res.body;
    } else if (res && res.body != null) {
      text = String(res.body);
    }
    if (!text && res && typeof res.json === 'function') {
      try {
        var parsed = await res.json();
        if (parsed != null) text = typeof parsed === 'string' ? parsed : JSON.stringify(parsed);
      } catch (_) { /* keep empty */ }
    } else if (!text && res && res.json != null && typeof res.json !== 'function') {
      try { text = typeof res.json === 'string' ? res.json : JSON.stringify(res.json); } catch (_) {}
    }
    return { status: status, text: String(text || ''), headers: (res && res.headers) || {} };
  }

  async function requestJson(url, headers, timeoutMs) {
    var res = await fetchv2(url, headers || {}, 'GET', null, { timeoutMs: timeoutMs });
    var status = Number(res && (res.status || res.statusCode)) || 0;
    var data = null;
    if (res && typeof res.json === 'function') {
      try { data = await res.json(); } catch (_) { data = null; }
    } else if (res && res.json != null) {
      data = res.json;
    }
    if (data == null && res && typeof res.body === 'string' && res.body) {
      try { data = JSON.parse(res.body); } catch (_) { data = null; }
    }
    if (data == null && res && typeof res.text === 'function') {
      try {
        var t = await res.text();
        if (t) data = JSON.parse(t);
      } catch (_) { data = null; }
    }
    return { status: status, data: data, headers: (res && res.headers) || {} };
  }

  /* ---------------- base64 / hex / xor (no atob, no Buffer) ---------------- */
  var B64_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
  function b64ToBytes(s) {
    var cleanS = String(s || '').replace(/\s+/g, '');
    var out = [], i, c1, c2, c3, c4, b1, b2, b3;
    for (i = 0; i < cleanS.length; i += 4) {
      c1 = B64_ALPHABET.indexOf(cleanS.charAt(i));
      c2 = B64_ALPHABET.indexOf(cleanS.charAt(i + 1));
      c3 = B64_ALPHABET.indexOf(cleanS.charAt(i + 2));
      c4 = B64_ALPHABET.indexOf(cleanS.charAt(i + 3));
      if (c1 < 0 || c2 < 0) return null;
      if (c3 < 0) c3 = 64; if (c4 < 0) c4 = 64;
      b1 = (c1 << 2) | (c2 >> 4);
      b2 = ((c2 & 15) << 4) | (c3 >> 2);
      b3 = ((c3 & 3) << 6) | c4;
      out.push(b1);
      if (c3 !== 64) out.push(b2);
      if (c4 !== 64) out.push(b3);
    }
    return out;
  }
  function bytesToAscii(bytes) {
    var s = '';
    for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i] & 255);
    return s;
  }
  function isHexString(s) {
    if (!s || s.length % 2 !== 0) return false;
    for (var i = 0; i < s.length; i++) {
      var c = s.charCodeAt(i);
      var ok = (c >= 48 && c <= 57) || (c >= 65 && c <= 70) || (c >= 97 && c <= 102);
      if (!ok) return false;
    }
    return true;
  }
  function hexToBytes(hex) {
    var out = [];
    for (var i = 0; i < hex.length; i += 2) {
      out.push(parseInt(hex.substr(i, 2), 16));
    }
    return out;
  }
  function isKnownProviderUrl(s) {
    var low = String(s).toLowerCase();
    for (var i = 0; i < PROVIDER_SUBSTRINGS.length; i++) {
      if (low.indexOf(PROVIDER_SUBSTRINGS[i]) >= 0) return true;
    }
    return false;
  }
  function splitQueryParams(url) {
    var out = [];
    var q = String(url || '').indexOf('?');
    if (q < 0) return out;
    var parts = String(url).slice(q + 1).split('&');
    for (var i = 0; i < parts.length; i++) {
      var eq = parts[i].indexOf('=');
      if (eq < 0) continue;
      var v = parts[i].slice(eq + 1);
      try { v = decodeURIComponent(v.replace(/\+/g, ' ')); } catch (_) {}
      out.push(v);
    }
    return out;
  }
  function decryptWatch2(watch2Url) {
    var params = splitQueryParams(watch2Url);
    for (var p = 0; p < params.length; p++) {
      var bytes = b64ToBytes(params[p]);
      if (!bytes || !bytes.length) continue;
      var hex = bytesToAscii(bytes);
      if (!isHexString(hex)) continue;
      var enc = hexToBytes(hex);
      for (var key = 0; key < 256; key++) {
        var dec = '';
        for (var i = 0; i < enc.length; i++) dec += String.fromCharCode(enc[i] ^ key);
        if (dec.indexOf('http://') === 0 || dec.indexOf('https://') === 0) {
          if (isKnownProviderUrl(dec)) return dec;
        }
      }
    }
    return null;
  }

  /* ---------------- catalogue ---------------- */
  async function fetchCatalogue(deadline) {
    if (catalogueCache.items && now() - catalogueCache.at < 10 * 60 * 1000) return catalogueCache.items;
    var res = await requestJson(API + '/api/animes', mergeHeaders(), timeLeft(deadline, 20000));
    if (res.status !== 200 || !Array.isArray(res.data)) throw new Error('Franime catalogue HTTP ' + res.status);
    catalogueCache = { at: now(), items: res.data };
    return res.data;
  }

  function normTitle(s) { return String(s == null ? '' : s).toLowerCase().replace(/[^a-z0-9\u00e0-\u024f\u1e00-\u1eff]+/gi, ''); }
  function titleOf(a) {
    if (!a) return '';
    var t = a.title || (a.titles && (a.titles.en || a.titles.en_us || a.titles.en_jp)) || a.titleO || '';
    return clean(t);
  }
  function imageOf(a) {
    if (!a) return '';
    var img = a.affiche_small || a.affiche || '';
    return String(img || '').trim();
  }
  function yearOf(a) {
    var d = String((a && (a.startDate || a.year)) || '');
    var m = d.match(/(\d{4})/);
    return m ? m[1] : '';
  }
  function cardOf(a) {
    var id = String(a.id);
    return {
      id: id, href: id, title: titleOf(a), image: imageOf(a), poster: imageOf(a),
      type: 'video', description: clean(a.description || ''),
      year: yearOf(a), format: String(a.format || ''), status: String(a.status || '')
    };
  }

  async function fetchAnimeById(id, deadline) {
    var res = await requestJson(API + '/api/anime-by-id/' + encodeURIComponent(id), mergeHeaders(), timeLeft(deadline, 12000));
    if (res.status === 200 && res.data && (res.data.id != null)) return res.data;
    var cat = await fetchCatalogue(deadline);
    for (var i = 0; i < cat.length; i++) {
      if (String(cat[i].id) === String(id)) return cat[i];
    }
    throw new Error('Franime details HTTP ' + res.status);
  }

  function parseAnimeId(value) {
    var s = String(value == null ? '' : value).trim();
    if (!s) return '';
    var m = s.match(/anime-by-id\/(\d+)/) || s.match(/\/(\d{2,})\/?$/);
    if (m) return m[1];
    if (/^\d+$/.test(s)) return s;
    var bar = s.match(/^franime:\/\/(\d+)\//);
    if (bar) return bar[1];
    return '';
  }
  function parseEpisodeHref(value) {
    var s = String(value == null ? '' : value).trim();
    var m = s.match(/^franime:\/\/(\d+)\/(\d+)\/(\d+)$/);
    if (!m) return null;
    return { animeId: m[1], saison: Number(m[2]), episode: Number(m[3]) };
  }
  function episodeHref(animeId, s, e) { return 'franime://' + animeId + '/' + s + '/' + e; }

  function normLang(lang) {
    var v = String(lang == null ? '' : lang).trim().toLowerCase();
    if (v === 'dub' || v === 'vf' || v === 'fr' || v === 'french' || v === 'vff') return 'vf';
    return 'vo';
  }
  function isSkippedLecteur(name) {
    var v = String(name || '').toLowerCase();
    for (var i = 0; i < UNSUPPORTED_LECTEURS.length; i++) {
      if (v.indexOf(UNSUPPORTED_LECTEURS[i]) >= 0) return true;
    }
    return false;
  }

  /* ---------------- search / details / episodes ---------------- */
  async function searchResults(query) {
    var deadline = now() + 20000;
    var term = String(query == null ? '' : query).trim().toLowerCase();
    var cat = await fetchCatalogue(deadline);
    var out = [];
    var i, a;
    if (!term) {
      var sorted = cat.slice().sort(function (x, y) {
        return Number(y.note || 0) - Number(x.note || 0);
      });
      for (i = 0; i < sorted.length && out.length < 30; i++) {
        if (sorted[i].nsfw) continue;
        out.push(cardOf(sorted[i]));
      }
      return out;
    }
    var starts = [], contains = [];
    var normTerm = normTitle(term);
    for (i = 0; i < cat.length; i++) {
      a = cat[i];
      if (a.nsfw) continue;
      var variants = [
        a.titleO, a.title,
        a.titles && a.titles.en, a.titles && a.titles.en_us,
        a.titles && a.titles.en_jp, a.titles && a.titles.ja_jp
      ];
      var hit = false, head = false;
      for (var v = 0; v < variants.length; v++) {
        var t = String(variants[v] == null ? '' : variants[v]).toLowerCase();
        if (!t) continue;
        if (t.indexOf(term) >= 0) { hit = true; if (t.indexOf(term) === 0) head = true; }
        else if (normTerm && normTitle(t).indexOf(normTerm) >= 0) { hit = true; }
      }
      if (hit) (head ? starts : contains).push(a);
    }
    var ranked = starts.concat(contains).slice(0, 30);
    for (i = 0; i < ranked.length; i++) out.push(cardOf(ranked[i]));
    return out;
  }

  async function extractDetails(urlOrId) {
    var deadline = now() + 20000;
    var id = parseAnimeId(urlOrId);
    if (!id) throw new Error('Franime details: invalid id');
    var a = await fetchAnimeById(id, deadline);
    var card = cardOf(a);
    var genres = Array.isArray(a.themes) ? a.themes.map(function (g) { return clean(g); }).filter(Boolean) : [];
    return {
      id: String(a.id), href: String(a.id), url: SITE + '/anime/' + String(a.id),
      title: card.title, originalTitle: clean(a.titleO || ''),
      description: clean(a.description || ''), synopsis: clean(a.description || ''),
      image: card.image, poster: card.image, banner: String(a.banner || ''),
      year: yearOf(a), format: String(a.format || ''), status: String(a.status || ''),
      genres: genres, rating: a.note != null ? String(a.note) : '',
      type: 'video'
    };
  }

  async function extractEpisodes(seriesId) {
    var deadline = now() + 20000;
    var id = parseAnimeId(seriesId);
    if (!id) return [];
    var a = await fetchAnimeById(id, deadline);
    var saisons = Array.isArray(a.saisons) ? a.saisons : [];
    var out = [];
    for (var s = 0; s < saisons.length; s++) {
      var eps = Array.isArray(saisons[s].episodes) ? saisons[s].episodes : [];
      for (var e = 0; e < eps.length; e++) {
        var ep = eps[e] || {};
        var vo = (ep.lang && ep.lang.vo && ep.lang.vo.lecteurs) || [];
        var vf = (ep.lang && ep.lang.vf && ep.lang.vf.lecteurs) || [];
        out.push({
          id: episodeHref(String(a.id), s, e),
          href: episodeHref(String(a.id), s, e),
          number: e + 1, episodeNumber: e + 1, season: s + 1,
          seasonTitle: clean(saisons[s].title || ('Saison ' + (s + 1))),
          title: clean(ep.title) || ('Episode ' + (e + 1)),
          subAvailable: Array.isArray(vo) && vo.length > 0,
          dubAvailable: Array.isArray(vf) && vf.length > 0
        });
      }
    }
    return out;
  }

  /* ---------------- providers ---------------- */
  function headerOf(ct) { return String(ct || '').toLowerCase(); }

  async function verifyMp4(url, referer, deadline) {
    try {
      var res = await requestText(url, { 'User-Agent': UA, 'Referer': referer || (SITE + '/'), 'Range': 'bytes=0-1023' }, timeLeft(deadline, 6000));
      var ct = headerOf(res.headers && (res.headers['content-type'] || res.headers['Content-Type']));
      if ((res.status === 200 || res.status === 206) && /video\/|application\/octet-stream/i.test(ct)) return true;
      if (res.status === 200 || res.status === 206) {
        var body = String(res.text || '');
        if (body && body.length > 64 && body.indexOf('<html') < 0 && body.indexOf('<!DOCTYPE') < 0) return true;
      }
      return false;
    } catch (_) { return false; }
  }
  async function verifyHls(url, referer, deadline) {
    try {
      var res = await requestText(url, { 'User-Agent': UA, 'Referer': referer || (SITE + '/') }, timeLeft(deadline, 8000));
      if (res.status !== 200 && res.status !== 206) return false;
      var ct = headerOf(res.headers && (res.headers['content-type'] || res.headers['Content-Type']));
      if (/text\/html/i.test(ct)) return false;
      return String(res.text || '').indexOf('#EXTM3U') >= 0;
    } catch (_) { return false; }
  }

  async function resolveSibnet(embedUrl, deadline) {
    var page = await requestText(embedUrl, mergeHtmlHeaders({ 'Referer': SITE + '/' }), timeLeft(deadline, 8000));
    if (page.status !== 200) throw new Error('sibnet embed HTTP ' + page.status);
    var m = page.text.match(/src:\s*["'](\/v\/[a-fA-F0-9]+\/\d+\.mp4)["']/);
    if (!m) throw new Error('sibnet token path missing');
    var vUrl = 'https://video.sibnet.ru' + m[1];
    var direct = await requestText(vUrl, mergeHtmlHeaders({ 'Referer': embedUrl }), timeLeft(deadline, 6000), { followRedirects: false });
    var loc = direct.headers && (direct.headers.location || direct.headers.Location);
    var cdn = '';
    if (loc) cdn = String(loc).indexOf('//') === 0 ? 'https:' + String(loc) : String(loc);
    var candidate = cdn || vUrl;
    if (await verifyMp4(candidate, embedUrl, deadline)) {
      return { url: candidate, headers: { 'User-Agent': UA, 'Referer': embedUrl }, streamType: 'mp4' };
    }
    throw new Error('sibnet media probe rejected');
  }

  async function resolveVidmoly(embedUrl, deadline) {
    var page = await requestText(embedUrl, mergeHtmlHeaders({ 'Referer': SITE + '/' }), timeLeft(deadline, 8000));
    if (page.status !== 200) throw new Error('vidmoly embed HTTP ' + page.status);
    var m = page.text.match(/file:\s*["']([^"']+\.m3u8[^"']*)["']/);
    if (!m) throw new Error('vidmoly m3u8 missing');
    var hls = m[1];
    if (await verifyHls(hls, embedUrl, deadline)) {
      return { url: hls, headers: { 'User-Agent': UA, 'Referer': embedUrl }, streamType: 'hls' };
    }
    throw new Error('vidmoly playlist probe rejected');
  }

  async function resolveSendvid(embedUrl, deadline) {
    var page = await requestText(embedUrl, mergeHtmlHeaders({ 'Referer': SITE + '/' }), timeLeft(deadline, 8000));
    if (page.status !== 200) throw new Error('sendvid embed HTTP ' + page.status);
    var m = page.text.match(/<source[^>]+src="([^"]+\.(?:m3u8|mp4)[^"]*)"/i) ||
            page.text.match(/file:\s*["']([^"']+\.(?:m3u8|mp4)[^"']*)["']/);
    if (!m) throw new Error('sendvid source missing');
    var media = m[1] || m[2];
    if (/\.m3u8(\?|$)/i.test(media)) {
      if (await verifyHls(media, embedUrl, deadline)) {
        return { url: media, headers: { 'User-Agent': UA, 'Referer': embedUrl }, streamType: 'hls' };
      }
    } else {
      if (await verifyMp4(media, embedUrl, deadline)) {
        return { url: media, headers: { 'User-Agent': UA, 'Referer': embedUrl }, streamType: 'mp4' };
      }
    }
    throw new Error('sendvid media probe rejected');
  }

  /* ---------------- stream ---------------- */
  async function extractStreamUrl(episodeHref, lang) {
    var deadline = now() + 24000;
    var ref = parseEpisodeHref(episodeHref);
    if (!ref) return { streams: [], subtitles: [], lang: normLang(lang) === 'vf' ? 'dub' : 'sub', error: { message: 'Franime: invalid episode identity.' } };
    var wantApi = normLang(lang);
    var wantOut = wantApi === 'vf' ? 'dub' : 'sub';
    var anime;
    try {
      anime = await fetchAnimeById(ref.animeId, deadline);
    } catch (e) {
      return { streams: [], subtitles: [], lang: wantOut, error: { message: 'Franime details failed: ' + String((e && e.message) || e) } };
    }
    var saisons = Array.isArray(anime.saisons) ? anime.saisons : [];
    if (!saisons[ref.saison] || !Array.isArray(saisons[ref.saison].episodes) || !saisons[ref.saison].episodes[ref.episode]) {
      return { streams: [], subtitles: [], lang: wantOut, error: { message: 'Franime: episode out of range (no substitution applied).' } };
    }
    var ep = saisons[ref.saison].episodes[ref.episode];
    var lecteurs = ((ep.lang && ep.lang[wantApi] && ep.lang[wantApi].lecteurs) || []).slice();
    if (!lecteurs.length) {
      return { streams: [], subtitles: [], lang: wantOut, error: { message: wantApi === 'vf' ? 'Franime: no VF (dub) lecteur for this episode.' : 'Franime: no VO (sub) lecteur for this episode.' } };
    }
    var servers = [], seen = {}, skipped = [];
    for (var i = 0; i < lecteurs.length; i++) {
      if (now() >= deadline) break;
      var name = String(lecteurs[i] || '');
      if (!name || isSkippedLecteur(name)) { skipped.push(name || ('index ' + i)); continue; }
      var watch2 = '';
      try {
        var lr = await requestText(
          API + '/api/anime/' + encodeURIComponent(ref.animeId) + '/' + ref.saison + '/' + ref.episode + '/' + wantApi + '/' + i,
          mergeHeaders(), timeLeft(deadline, 8000));
        if (lr.status !== 200 || !lr.text || lr.text.indexOf('https://') !== 0) continue;
        watch2 = lr.text.trim();
      } catch (_) { continue; }
      var embed = null;
      try { embed = decryptWatch2(watch2); } catch (_) { embed = null; }
      if (!embed) continue;
      var low = embed.toLowerCase();
      try {
        var resolved = null;
        if (low.indexOf('sibnet.ru') >= 0) resolved = await resolveSibnet(embed, deadline);
        else if (low.indexOf('vidmoly') >= 0) resolved = await resolveVidmoly(embed, deadline);
        else if (low.indexOf('sendvid') >= 0) resolved = await resolveSendvid(embed, deadline);
        else { skipped.push(name); continue; }
        if (!resolved || !resolved.url || seen[resolved.url]) continue;
        seen[resolved.url] = true;
        servers.push({
          name: name + ' ' + wantApi,
          label: (wantOut === 'dub' ? 'dub ' : 'sub ') + name,
          url: resolved.url, headers: resolved.headers,
          streamType: resolved.streamType, lang: wantOut
        });
        if (servers.length >= 3) break;
      } catch (_) { /* try next lecteur */ }
    }
    if (!servers.length) {
      return { streams: [], subtitles: [], lang: wantOut, error: { message: 'Franime: no verified ' + wantApi.toUpperCase() + ' stream (skipped: ' + skipped.join(', ') + ').' } };
    }
    var primary = servers[0];
    var flat = [];
    for (var f = 0; f < servers.length; f++) {
      flat.push((wantOut === 'dub' ? 'dub ' : 'sub ') + servers[f].name.split(' ')[0]);
      flat.push(servers[f].url);
    }
    return {
      url: primary.url, headers: primary.headers, streamType: primary.streamType, lang: wantOut,
      streams: flat,
      quality: 'Auto', defaultQuality: 'Auto',
      qualities: [{ label: 'Auto', url: primary.url, headers: primary.headers }],
      subtitles: [],
      servers: servers.map(function (s) {
        return { name: s.name, label: s.label, url: s.url, headers: s.headers, streamType: s.streamType, lang: s.lang, subtitles: [] };
      }),
      provider: 'franime'
    };
  }

  /* ---------------- discovery (lightweight endpoints, no catalogue fetch) -- */
  async function fetchTop(deadline) {
    var res = await requestJson(API + '/api/discord/voted/render-top-15-of-bestanimes', mergeHeaders(), timeLeft(deadline, 12000));
    if (res.status !== 200 || !Array.isArray(res.data)) throw new Error('Franime top HTTP ' + res.status);
    return res.data;
  }
  async function fetchCalendar(deadline) {
    var res = await requestJson(API + '/api/calendrier_data', mergeHeaders(), timeLeft(deadline, 12000));
    if (res.status !== 200 || !res.data || !Array.isArray(res.data.data)) throw new Error('Franime calendar HTTP ' + res.status);
    return res.data.data;
  }
  function calendarCard(c) {
    var id = String(c.id_anime);
    var img = String(c.affiche || '');
    return {
      id: id, href: id, title: clean(c.title_anime), image: img, poster: img,
      type: 'video', description: clean((c.jour ? ('Sortie : ' + c.jour) : '') + (c.saison ? (' - Saison ' + c.saison) : ''))
    };
  }
  function toCard(a) { return cardOf(a); }
  async function discoveryHome() {
    var deadline = now() + 20000;
    var sections = [];
    var seen = {};
    function dedupe(items) {
      var out = [];
      for (var i = 0; i < items.length; i++) {
        var key = String(items[i] && items[i].href || '').trim();
        if (!key || seen[key]) continue;
        seen[key] = true;
        out.push(items[i]);
      }
      return out;
    }
    try {
      var top = await fetchTop(deadline);
      var items = [];
      for (var i = 0; i < top.length && items.length < 8; i++) {
        if (top[i].nsfw || !titleOf(top[i])) continue;
        items.push(toCard(top[i]));
      }
      items = dedupe(items);
      if (items.length) sections.push({ id: 'top', title: 'Top animes', style: 'hero', items: items });
    } catch (_) { /* calendar-only fallback */ }
    try {
      var cal = await fetchCalendar(deadline);
      var cards = [], localSeen = {};
      for (var j = 0; j < cal.length && cards.length < 30; j++) {
        var id = String(cal[j].id_anime);
        if (!id || localSeen[id] || !cal[j].title_anime) continue;
        localSeen[id] = true;
        cards.push(calendarCard(cal[j]));
      }
      cards = dedupe(cards);
      if (cards.length) sections.push({ id: 'calendrier', title: 'Calendrier des sorties', style: 'poster', items: cards, viewAll: { mode: 'feed', feedId: 'calendrier' } });
    } catch (_) { /* top-only fallback */ }
    return { sections: sections };
  }
  async function discoveryFeed(feedId, page) {
    var deadline = now() + 20000;
    var pageNum = Math.max(1, Number(page) || 1);
    var feed = String(feedId || 'top15');
    if (feed === 'top15' || feed === 'top') {
      if (pageNum > 1) return { items: [], page: pageNum, hasMore: false };
      var top = await fetchTop(deadline);
      var items = [];
      for (var i = 0; i < top.length && items.length < 50; i++) {
        if (top[i].nsfw || !titleOf(top[i])) continue;
        items.push(toCard(top[i]));
      }
      return { items: items, page: 1, hasMore: false };
    }
    if (feed === 'calendrier') {
      if (pageNum > 1) return { items: [], page: pageNum, hasMore: false };
      var cal = await fetchCalendar(deadline);
      var seen = {}, cards = [];
      for (var j = 0; j < cal.length && cards.length < 50; j++) {
        var id = String(cal[j].id_anime);
        if (!id || seen[id] || !cal[j].title_anime) continue;
        seen[id] = true;
        cards.push(calendarCard(cal[j]));
      }
      return { items: cards, page: 1, hasMore: false };
    }
    if (feed === 'catalogue') {
      var cat = await fetchCatalogue(deadline);
      var pool = cat.filter(function (a) { return !a.nsfw && a.id != null && titleOf(a); });
      var per = 50, start = (pageNum - 1) * per;
      return { items: pool.slice(start, start + per).map(toCard), page: pageNum, hasMore: start + per < pool.length };
    }
    return { items: [], page: pageNum, hasMore: false };
  }

  /* ---------------- exports ---------------- */
  globalThis.searchResults = searchResults;
  globalThis.extractDetails = extractDetails;
  globalThis.extractEpisodes = extractEpisodes;
  globalThis.extractStreamUrl = extractStreamUrl;
  globalThis.discoveryHome = discoveryHome;
  globalThis.discoveryFeed = discoveryFeed;
})();
